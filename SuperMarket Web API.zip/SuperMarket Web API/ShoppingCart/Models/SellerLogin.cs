﻿namespace UserManagement_1.Models
{
    public class SellerLogin
    {
       
        public int SellerId { get; set; }
        public string sellerEmail { get; set; }
        public string sellerPassword { get; set; }
    }
}
