﻿namespace UserManagement_1.Models
{
    public class CustomerLogin
    {
        public int custId { get; set; }
        public string custEmail { get; set; }
        public string custPassword { get; set; }
    }
}
